sap.ui.define([
	"sapfiori/project1/test/unit/controller/View.controller"
], function () {
	"use strict";
});
