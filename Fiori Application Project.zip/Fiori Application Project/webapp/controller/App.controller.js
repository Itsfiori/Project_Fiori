sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/routing/History"
    ],
    function(BaseController,History) {
      "use strict";
  
      return BaseController.extend("sap.fiori.project1.controller.App", {
        onInit() {
          
        },
        onload: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onload");
          oRouter.navTo("detail");
        },
        back : function(oEvent){
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onOpen");
          oRouter.navTo("");
        },
        onOpen: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onOpen");
          oRouter.navTo("questions");
        },
        onPreview: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onPreview");
          oRouter.navTo("vendorprice");
        },
        fetchversion: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("fetchversion");
          oRouter.navTo("version");
        },
        onNavBack: function () {
          var oHistory = History.getInstance();
          var sPreviousHash = oHistory.getPreviousHash();
    
          if (sPreviousHash !== undefined) {
            window.history.go(-1);
          } else {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("app", {}, true);
          }
        }

      });
    }
  );