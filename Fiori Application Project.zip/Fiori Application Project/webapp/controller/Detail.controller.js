sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/routing/History"
    ],
    function(BaseController,History) {
      "use strict";
  
      return BaseController.extend("sap.fiori.project1.controller.App", {
        onInit() {
          
        },
        onload: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onload");
          oRouter.navTo("detail");
        },
        onload2:function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onload");
          oRouter.navTo("overview");
        },

        onPreview: function(oEvent)
        {
          var oModel = new JSONModel(oData);
          this.getView().setModel(oModel);
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onPreview");
          oRouter.navTo("vendorprice");
        },
        fetchversion: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("fetchversion");
          oRouter.navTo("version");
        },
        onNavBack: function () {
          var oHistory = History.getInstance();
          var sPreviousHash = oHistory.getPreviousHash();
    
          if (sPreviousHash !== undefined) {
            window.history.go(-1);
          } else {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("app", {}, true);
          }
        },

        onCreate : function () {
          var oList = this.byId("table"),
            oBinding = oList.getBinding("items");
            oList.getItems().some(function (oItem) {
              if (oItem.getBindingContext() === oContext) {
                oItem.focus();
                oItem.setSelected(true);
                return true;
              }
            });
          },

      });
    }
  );
  