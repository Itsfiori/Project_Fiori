sap.ui.define(
    [
      "sap/ui/core/mvc/Controller",
      "sap/ui/model/json/JSONModel",        
    ],
    function(BaseController, JSONModel) {
      "use strict";
  
      return BaseController.extend("sap.fiori.project1.controller.Vendorprice", {
        onInit : function () {
          // set data model on view
          var oData = {
             recipient : {
                version : "VERSIONS",
                "text1": "Version 1",
			          "text2": "Version 2",
			          "text3": "Version 3",
			          "text4": "Version 4",
			          "text5": "Version 5",
			          "text6": "Version 6"
             },
             vender1:
              {
                "icon":"Vendor 1      -     $30",
                "title": "Version",
                "text1": " $70.85",
                "text2": " $30.40",
                "text3": " $50.20",
                "text4": " $38.64",
                "text5": " $30.50",
                "text6": " $36.44",
          
                "subtitle": "$30 Grand Total"
          
              },
              vender2:
              {
                "icon":"Vendor 2      -      $40",
                "title": "Version",
                "text1": " $10.85",
                "text2": " $20.40",
                "text3": " $30.20",
                "text4": " $48.64",
                "text5": " $50.50",
                "text6": " $66.44",
                "subtitle": "$40 Grand Total"
              },
              vender3:
              {
                "icon":"Vendor 3      -      $45",
                "title": "Version",
                "text1": " $10.85",
                "text2": " $20.40",
                "text3": " $30.20",
                "text4": " $48.64",
                "text5": " $50.50",
                "text6": " $66.44",
                "subtitle": "$45 Grand Total"
              }
          };
          var oModel = new JSONModel(oData);
          this.getView().setModel(oModel);
       },
        onload: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onload");
          oRouter.navTo("detail");
        },
        onload2:function(oEvent)
        {  var oModel = new JSONModel(oData);
          this.getView().setModel(oModel);
          var oRouter = this.getOwnerComponent().getRouter();
          oRouter.navTo("venderprice");

     
        },

        onNavBack: function () {
          var oHistory = History.getInstance();
          var sPreviousHash = oHistory.getPreviousHash();
    
          if (sPreviousHash !== undefined) {
            window.history.go(-1);
          } else {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("detail", {}, true);
          }
        }
       

      });
    }
  );
  