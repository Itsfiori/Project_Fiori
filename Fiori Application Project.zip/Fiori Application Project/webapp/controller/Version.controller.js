sap.ui.define(
    [
      "sap/ui/core/mvc/Controller",
      "sap/ui/model/json/JSONModel",        
    ],
    function(BaseController, JSONModel) {
      "use strict";
  
      return BaseController.extend("sap.fiori.project1.controller.Version", {
        onInit : function () {
          // set data model on view
          var oData = {
             recipient : {
                version : "VERSIONS",
                "text1": "Version 1",
			          "text2": "Version 2",
			          "text3": "Version 3",
			          "text4": "Version 4",
			          "text5": "Version 5",
			          "text6": "Version 6"
             },
             vender1:
              {
                "icon":"Vendor 1      -     $30",
                "title": "Version",
                "text1": " $70.85",
                "text2": " $60.40",
                "text3": " $68.20",
                "text4": " $59.64",
                "text5": " $42.50",
                "text6": " $30.44",
          
                "subtitle": "$30 Grand Total"
          
              },
              vender2:
              {
                "icon":"Vendor 2      -      $40",
                "title": "Version",
                "text1": " $70.85",
                "text2": " $65.40",
                "text3": " $60.20",
                "text4": " $58.64",
                "text5": " $55.50",
                "text6": " $40.00",
                "subtitle": "$40 Grand Total"
              },
              vender3:
              {
                "icon":"Vendor 4      -      $15",
                "title": "Version",
                "text1": " $50.85",
                "text2": " $45.40",
                "text3": " $36.20",
                "text4": " $30.64",
                "text5": " $20.50",
                "text6": " $15.44",
                "subtitle": "$15 Grand Total"
              },
              vender4:
              {
                "icon":"Vendor 3      -      $29",
                "title": "Version",
                "text1": " $70.85",
                "text2": " $68.40",
                "text3": " $60.20",
                "text4": " $40.64",
                "text5": " $30.50",
                "text6": " $29.00",
                "subtitle": "$29.00 Grand Total"
              }
          };
          var oModel = new JSONModel(oData);
          this.getView().setModel(oModel);
       },
        onload: function(oEvent)
        {
          var oRouter = this.getOwnerComponent().getRouter();
          console.log("onload");
          oRouter.navTo("detail");
        },
        onload2:function(oEvent)
        {  var oModel = new JSONModel(oData);
          this.getView().setModel(oModel);
          var oRouter = this.getOwnerComponent().getRouter();
          oRouter.navTo("venderprice");

     
        },

        onNavBack: function () {
          var oHistory = History.getInstance();
          var sPreviousHash = oHistory.getPreviousHash();
    
          if (sPreviousHash !== undefined) {
            window.history.go(-1);
          } else {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("app", {}, true);
          }
        }

      });
    }
  );
  